#include <iostream>
#include <vector>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/video/tracking.hpp"
#include "opencv2/features2d/features2d.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/objdetect/objdetect.hpp"
#include "featuretracker.h"
#include <stdlib.h>

using namespace std;
using namespace cv;

String face_cascade_name = "haarcascade_frontalface_alt.xml";
CascadeClassifier face_cascade;
string window_name = "Capture - Face detection";
RNG rng(12345);

int main( int argc, const char** argv )
{
	Mat frame;
	if( !face_cascade.load( face_cascade_name ) ){ 
		cout << "--(!)Error loading" << endl; 
		return -1; 
	}

	VideoCapture cap;
	//cap.open(1);			//���ǲ�������ͷ����ȡ������ע����䣬��ע����������䣻
	cap.open("test1.mpg");
	if (!cap.isOpened()){
		cout << "Open VideoCapture failed!" << endl;
		return -1;
	}
	
	FeatureTrakcer tracker;
	vector<Rect> faces;
	vector<Rect> pre_tracked;
	vector<Rect> tracked;
	Mat output;
	int count = 0, sum = 0;
	namedWindow(window_name);

	for (; ;){
		cap >> frame;
		if (!frame.data){
			break;
		}
		if (count % 32 == 0){
			cout << "���½�������̽�⣡��������" << endl;
			count++;
			faces.clear();
			face_cascade.detectMultiScale( frame, faces, 1.1, 3, 0|CV_HAAR_DO_CANNY_PRUNING, Size(30, 30) );
		}
		tracker.process(frame, faces, output, tracked);
		tracker.setFlag(true);
		imshow(window_name, output);
		waitKey(100);
		++count;
	}
	return 0;
}