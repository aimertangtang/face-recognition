#ifndef FTRACKER
#define FTRACKER

#include <string>
#include <vector>
#include <algorithm>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/features2d/features2d.hpp"
#include "opencv2/video/tracking.hpp"

using namespace cv;
using namespace std;

class FeatureTrakcer{
	Mat frame_gray;
	Mat gray_prev;
	vector<vector<Point2f> > points;
	vector<vector<Point2f> > new_points;
	vector<vector<uchar> > status;
	vector<vector<float> > err;
	vector<Point2f> features;
	vector<int> width;
	vector<int> height;
	//vector<Rect> trackedResult;

	int max_count;
	int num;
	//int width, height;
	double qlevel;
	double minDist;
	bool flag;
	Scalar color[10];
	string face_cascade_name;
	CascadeClassifier face_cascade;

public:
	FeatureTrakcer() : max_count(500), qlevel(0.01), minDist(8.0), num(0), flag(0), width(0), height(0)
	{ 
		color[0] = Scalar(255, 0, 0);
		color[1] = Scalar(0, 255, 0);
		color[2] = Scalar(0, 0, 255);
		color[3] = Scalar(255, 255, 0);
		color[4] = Scalar(255, 0, 255);
		color[5] = Scalar(0, 255, 255);
		color[6] = Scalar(0, 0, 0);
		color[7] = Scalar(255, 120, 120);
		color[8] = Scalar(120, 255, 120);
		color[9] = Scalar(120, 120, 255);
	}

	void setCascadeName(string str){
		face_cascade_name = str;
		if (!face_cascade.load(face_cascade_name)){ 
			cout << "--(!)Error loading" << endl; 
			return; 
		}
	}

	void process(Mat &frame, vector<Rect> &faces, Mat &output, vector<Rect> &trackedRect){
		cvtColor(frame, frame_gray, CV_BGR2GRAY);
		frame.copyTo(output);

		//�ж��Ƿ���Ҫ����̽��������
		if (!flag){
			points.clear();
			new_points.clear();
			width.clear();
			height.clear();

			for( size_t i = 0; i < faces.size(); i++ ){
				width.push_back(faces[i].width);
				height.push_back(faces[i].height);
				
				Mat imageROI = frame_gray(Rect(faces[i].x, faces[i].y, 
					((faces[i].x + faces[i].width) >= frame_gray.cols) ? frame_gray.cols - faces[i].x : faces[i].width , 
					((faces[i].y + faces[i].height) >= frame_gray.rows) ? frame_gray.rows - faces[i].y : faces[i].height));
				
				features.clear();
				goodFeaturesToTrack(imageROI, features, max_count, qlevel, minDist);
				for (vector<Point2f>::iterator it = features.begin(); it != features.end(); ++it){
					it->x = it->x + faces[i].x;
					it->y = it->y + faces[i].y;
				}
				//features.resize(25);
				points.push_back(features);
			}
		}

		status.resize(points.size());
		err.resize(points.size());
		new_points.resize(points.size());
		
		if (gray_prev.empty()){
			frame_gray.copyTo(gray_prev);
		}

		double duration = static_cast<double>(getTickCount());
		for (size_t i = 0; i < points.size(); i++){
			calcOpticalFlowPyrLK(gray_prev, frame_gray, points[i], new_points[i], status[i], err[i]);
		}

		cout << "�������������㣡������" << endl;
		for (size_t i = 0; i < new_points.size(); i++){
			int k = 0;
			for (size_t j = 0; j < new_points[i].size(); j++){
				//�ж��������Ƿ��ƶ������Ƴ���Ƶ��Χ
				if (status[i][j]/*  && (abs(points[i][j].x - new_points[i][j].x) + abs(points[i][j].y - new_points[i][j].y) > 0.5)*/){
					new_points[i][k++] = new_points[i][j];
				}
			}
			new_points[i].resize(k);
			//cout << "The " << i << "  person has num of " << new_points[i].size() << "  points!!!!" << endl;
		}
		
		for (vector<vector<Point2f> >::iterator it = new_points.begin(); it != new_points.end();){
			if (0 == it->size()){
				it = new_points.erase(it);
			}
			else{
				++it;
			}
		}

		handleTrackedPoints(frame, output, faces, trackedRect);
		swap(points, new_points);
		swap(gray_prev, frame_gray);
	}

	void handleTrackedPoints(Mat &frame, Mat &output, vector<Rect> &faces, vector<Rect> &trackedRect) {
		vector<float> x;
		vector<float> y;

		//��ÿ������������������ģ�
		for (int i = 0; i < new_points.size(); i++){
			float tmpx = 0.0, tmpy = 0.0;
			for (int j = 0; j < new_points[i].size(); j++){
				//circle(output, new_points[i][j], 3, color[i % 10], -1);
				tmpx += new_points[i][j].x;
				tmpy += new_points[i][j].y;
			}
			tmpx /= new_points[i].size();
			tmpy /= new_points[i].size();
			x.push_back(tmpx);
			y.push_back(tmpy);

			//cout << "��ÿ������������" << endl;
		}

		trackedRect.clear();
		//int i = 0;
		for (size_t i = 0; i < new_points.size(); i++){
			Rect tmp;
			tmp.x = static_cast<int>(x[i] - width[i] / 2);
			tmp.y = static_cast<int>(y[i] - height[i] / 2);
			if (tmp.x < 0){
				tmp.x = 0;
			}
			if (tmp.y < 0){
				tmp.y = 0;
			}
			tmp.width = width[i];
			tmp.height = height[i];

			//cout << new_points[i].size() << " points !!" << endl;

			int num = 0;
			for (size_t j = 0; j < new_points[i].size(); j++){
				if (tmp.contains(new_points[i][j])){
					++num;
				}
			}
			
			trackedRect.push_back(tmp);
			if (num > new_points[i].size() * 0.6){
				rectangle(output, Point(tmp.x, tmp.y), Point(tmp.x + tmp.width, tmp.y + tmp.height), color[i % 10], 2);
				char p = char(int(i + 48));
				string str1 = "";
				string str = str1 + p;
				putText(output, str, Point(tmp.x + tmp.width / 2, tmp.y + tmp.height / 2), 3, 2, Scalar(0, 0, 0));
			}
		}
	}

	void setFlag(bool newFlag)
	{
		flag = newFlag;
	}
};

#endif