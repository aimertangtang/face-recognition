#ifndef VPROCESSOR
#define VPROCESSOR

#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"

using namespace std;
using namespace cv;

class FrameProcessor{
public:
	virtual void process(Mat &input, Mat &output) = 0;
};

class VideoProcessor{
private:
	VideoCapture capture;
	void (*process)(Mat &, Mat &);
	FrameProcessor *frameProcessor;

	bool callIt;
	string windowNameInput;
	string windowNameOutput;
	int delay;
	long fnumber;
	long frameToStop;
	bool stop;

	vector<string> images;
	vector<string>::const_iterator itImg;

	VideoWriter writer;
	string outputFile;
	int currentIndex;
	int digits;

public:
	VideoProcessor() : callIt(false), delay(-1), fnumber(0), stop(false), digits(0),
		frameToStop(-1), process(0), frameProcessor(0){ }

	bool setInput(string filename){
		fnumber = 0;
		capture.release();
		images.clear();
		return capture.open(filename);
	}

	bool setInput(int id){
		fnumber = 0;
		capture.release();
		images.clear();
		return capture.open(id);
	}

	void displayOutput(string wn){
		windowNameOutput = wn;
		namedWindow(windowNameOutput);
	}

	void setDelay(int d){
		delay = d;
	}

	void stopIt(){
		stop = true;
	}

	bool isStopped(){
		return stop;
	}

	bool isOpened(){
		return capture.isOpened();
	}

	void run(){
		Mat frame;
		Mat output;
		if (!capture.isOpened()){
			return;
		}
		stop = false;

		while (!stop){
			capture >> frame;
			if (!frame.data){
				break;
			}
			//imshow(windowNameInput, frame);

			frameProcessor->process(frame, output);

			imshow(windowNameOutput, output);
			
			if (waitKey(delay) >=0){
				stop = true;
			}
		}
	}
};


#endif